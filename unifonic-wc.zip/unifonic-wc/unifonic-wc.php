<?php
require('Unifonic/Autoload.php');
use \Unifonic\API\Client;
class Unifonic
{
	function __construct()
	{
		add_action( 'init', array($this,'discount_base') );
		add_filter( 'woocommerce_product_data_tabs', array($this,'add_my_custom_product_data_tab'), 99 , 1 );
		add_action('admin_menu', array($this, 'my_menu_pages'));
        // add_action( 'woocommerce_thankyou', array( $this , 'my_custom_tracking' ));
        // add_action( 'woocommerce_order_status_processing', array( $this , 'action_woocommerce_order_status_processing'), 10, 1 );

        // add_action( 'woocommerce_thankyou',  array($this, 'mysite_processing' ));
        add_action( 'woocommerce_order_status_pending', array($this, 'mysite_pending'));
        add_action( 'woocommerce_order_status_failed', array($this, 'mysite_failed'));
        add_action( 'woocommerce_order_status_on-hold', array($this, 'mysite_hold'));
        // Note that it's woocommerce_order_status_on-hold, not on_hold.
        add_action( 'woocommerce_order_status_processing', array($this, 'mysite_processing'));
        add_action( 'woocommerce_order_status_completed', array($this, 'mysite_completed'));
        add_action( 'woocommerce_order_status_refunded', array($this, 'mysite_refunded'));
        add_action( 'woocommerce_order_status_cancelled', array($this, 'mysite_cancelled'));

	}	

	function add_my_custom_product_data_tab( $product_data_tabs ) {
	    $product_data_tabs['unifonic-tab'] = array(
	        'label' => __( 'Unifonic', 'my_text_domain' ),
	        'target' => 'my_custom_product_data',
	    );
	    return $product_data_tabs;
	}

	public function discount_base() {
        if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
            $class = 'notice notice-error';
            $message = __("Error! <a href='https://wordpress.org/plugins/woocommerce/' target='_blank'>WooCommerce</a> Plugin is required to activate Woocommerce Unifonic", 'optinspin');
            printf('<div class="%1$s"><p>%2$s</p></div>', esc_attr($class), $message);
            if (!function_exists('deactivate_plugins')) {
                require_once(ABSPATH . 'wp-admin/includes/plugin.php');
            }
            deactivate_plugins(GIFT_BASEPATH);
        }

        // if (isset($_POST['coupon-discount'])) {
        // 	$this->setCoupen();
        // }
        // if (isset($_POST['offered-product'])) {
        // 	$this->setOfferProducts();
        // }
    }
    public function my_menu_pages(){
	    add_menu_page('Woo Unifonic', 'Woo Unifonic', 'manage_options', 'woo-unifonic', array($this,'woo_unifonic_output'), '', 70 );
	}

	public function woo_unifonic_output() { 
        global $wpdb;
    	$row = get_option( 'unifonic_data' );
		?>
		<div class="wrapper">
        <h1>Link Unifonic API</h1>
        <form action="" method="post" enctype="multipart/form-data">
            <label><b>Sender Name</b></label><br/>
            <?php if ($row['sender_name']): ?>
            <input type="text" id="sender_name" name="sender_name" value="<?php echo $row['sender_name'] ?>"> <br/>
            <?php else: ?>
            <input type="text" id="sender_name" name="sender_name"> <br/>
            <?php endif; ?>
            <br/>
            <label><b>Unifonic api key</b></label><br/>
            <?php if ($row['api_key']): ?>
            <input type="text" id="api_key" name="api_key" value="<?php echo $row['api_key'] ?>"> <br/>
            <?php else: ?>
            <input type="text" id="api_key" name="api_key"> <br/>
            <?php endif; ?>
            <br/>
            <input type="submit" name="submit">
        </form>
    </div>
    <?php 
    // include_once('wp-includes\option.php');
    if (isset($_POST['submit'])) {
        global $wpdb;
        $sender_name = sanitize_text_field($_POST['sender_name']);
        $api_key = sanitize_text_field($_POST['api_key']);
        $data = [
            'sender_name' => $sender_name,
            'api_key' => $api_key,
        ];

        $resp = update_option('unifonic_data', $data);
        wp_redirect($_SERVER['HTTP_REFERER']);
        exit;
        echo '<div class="success" style="color:green;"> Data saved successfully</div>';
        }

	}

    // confirm order message
    // function my_custom_tracking($value='', $order_id)
    // {
    //     $client = new Client();
    //     $response = $client->Messages->Send(0311******,'Thank Your order has been confirmed',get_option( 'unifonic_data' )['sender_name']);
    // }

    // // processing order message
    // function action_woocommerce_order_status_processing($value='', $order_id)
    // {
    //     $client = new Client();
    //     $response = $client->Messages->Send(0311******,'Your order is in processing',get_option( 'unifonic_data' )['sender_name']);
    // }

    function mysite_pending($order_id) {
        $order = wc_get_order( $order_id );
        $billing_email  = $order->get_billing_phone();
        $client = new Client();
        $response = $client->Messages->Send($order->get_billing_phone(),
'Dear '.$order->get_billing_first_name().' '.$order->get_billing_last_name().'

Thank you for your order.
Order '.$order->get_order_number().' of SAR '.$order->get_total(). ' has been '.$order->get_status().'

For More Information Contact Us: 920025833'
            ,get_option( 'unifonic_data' )['sender_name']);
        // arabic message
        $response = $client->Messages->Send($order->get_billing_phone(),
'عزيز '.$order->get_billing_first_name().' '.$order->get_billing_last_name().'

شكرا لتسوقك عبر موقع تمكين الإلكتروني..
رقم الطلب  '.$order->get_order_number().' اجمالي المبلغ  '.$order->get_total(). ' ريال و حالة الطلب   في انتظار الدفع

لمزيد من المعلومات نرجو منك التواصل معنا عبر الرقم الموحد:: 920025833'
            ,get_option( 'unifonic_data' )['sender_name']);
    }
    function mysite_failed($order_id) {
        $order = wc_get_order( $order_id );
        $billing_email  = $order->get_billing_phone();
        $client = new Client();
        $response = $client->Messages->Send($order->get_billing_phone(),
'Dear '.$order->get_billing_first_name().' '.$order->get_billing_last_name().'

Thank you for your order.
Order '.$order->get_order_number().' of SAR '.$order->get_total(). ' has been '.$order->get_status().'

For More Information Contact Us: 920025833'
            ,get_option( 'unifonic_data' )['sender_name']);
        // arabic message
        $response = $client->Messages->Send($order->get_billing_phone(),
'عزيز '.$order->get_billing_first_name().' '.$order->get_billing_last_name().'

شكرا لتسوقك عبر موقع تمكين الإلكتروني..
رقم الطلب  '.$order->get_order_number().' اجمالي المبلغ  '.$order->get_total(). ' ريال و حالة الطلب   فشل

لمزيد من المعلومات نرجو منك التواصل معنا عبر الرقم الموحد:: 920025833'
            ,get_option( 'unifonic_data' )['sender_name']);
    }
    function mysite_hold($order_id) {
        $order = wc_get_order( $order_id );
        $billing_email  = $order->get_billing_phone();
        $client = new Client();
        $response = $client->Messages->Send($order->get_billing_phone(),
'Dear '.$order->get_billing_first_name().' '.$order->get_billing_last_name().'

Thank you for your order.
Order '.$order->get_order_number().' of SAR '.$order->get_total(). ' has been '.$order->get_status().'

For More Information Contact Us: 920025833'
            ,get_option( 'unifonic_data' )['sender_name']);
        // arabic message
        $response = $client->Messages->Send($order->get_billing_phone(),
'عزيز '.$order->get_billing_first_name().' '.$order->get_billing_last_name().'

شكرا لتسوقك عبر موقع تمكين الإلكتروني..
رقم الطلب  '.$order->get_order_number().' اجمالي المبلغ  '.$order->get_total(). ' ريال و حالة الطلب   قيد الإنتظار

لمزيد من المعلومات نرجو منك التواصل معنا عبر الرقم الموحد:: 920025833'
            ,get_option( 'unifonic_data' )['sender_name']);
    }
    function mysite_processing($order_id) {
        $order = wc_get_order( $order_id );
        $client = new Client();
        //$response = $client->Messages->Send($billing_email,'Your order is on processing',get_option( 'unifonic_data' )['sender_name']);
        $response = $client->Messages->Send($order->get_billing_phone(),
'Dear '.$order->get_billing_first_name().' '.$order->get_billing_last_name().'

Thank you for your order.
Order '.$order->get_order_number().' of SAR '.$order->get_total(). ' has been '.$order->get_status().'

For More Information Contact Us: 920025833'
            ,get_option( 'unifonic_data' )['sender_name']);
        // arabic message
        $response = $client->Messages->Send($order->get_billing_phone(),
'عزيز '.$order->get_billing_first_name().' '.$order->get_billing_last_name().'

شكرا لتسوقك عبر موقع تمكين الإلكتروني..
رقم الطلب  '.$order->get_order_number().' اجمالي المبلغ  '.$order->get_total(). ' ريال و حالة الطلب    قيد التنفيذ

لمزيد من المعلومات نرجو منك التواصل معنا عبر الرقم الموحد:: 920025833'
            ,get_option( 'unifonic_data' )['sender_name']);
        // print_r($response);die();
    }
    function mysite_completed($order_id) {
        $order = wc_get_order( $order_id );
        $billing_email  = $order->get_billing_phone();
        $client = new Client();
        $response = $client->Messages->Send($order->get_billing_phone(),
'Dear '.$order->get_billing_first_name().' '.$order->get_billing_last_name().'

Thank you for your order.
Order '.$order->get_order_number().' of SAR '.$order->get_total(). ' has been '.$order->get_status().'

For More Information Contact Us: 920025833'
            ,get_option( 'unifonic_data' )['sender_name']);
        // arabic message
        $response = $client->Messages->Send($order->get_billing_phone(),
'عزيز '.$order->get_billing_first_name().' '.$order->get_billing_last_name().'

شكرا لتسوقك عبر موقع تمكين الإلكتروني..
رقم الطلب  '.$order->get_order_number().' اجمالي المبلغ  '.$order->get_total(). ' ريال و حالة الطلب   تم التنفيذ

لمزيد من المعلومات نرجو منك التواصل معنا عبر الرقم الموحد:: 920025833'
            ,get_option( 'unifonic_data' )['sender_name']);
    }
    function mysite_refunded($order_id) {
        $order = wc_get_order( $order_id );
        $billing_email  = $order->get_billing_phone();
        $client = new Client();
        $response = $client->Messages->Send($order->get_billing_phone(),
'Dear '.$order->get_billing_first_name().' '.$order->get_billing_last_name().'

Thank you for your order.
Order '.$order->get_order_number().' of SAR '.$order->get_total(). ' has been '.$order->get_status().'

For More Information Contact Us: 920025833'
            ,get_option( 'unifonic_data' )['sender_name']);
        // arabic message
        $response = $client->Messages->Send($order->get_billing_phone(),
'عزيز '.$order->get_billing_first_name().' '.$order->get_billing_last_name().'

شكرا لتسوقك عبر موقع تمكين الإلكتروني..
رقم الطلب  '.$order->get_order_number().' اجمالي المبلغ  '.$order->get_total(). ' ريال و حالة الطلب   تم الإسترجاع

لمزيد من المعلومات نرجو منك التواصل معنا عبر الرقم الموحد:: 920025833'
            ,get_option( 'unifonic_data' )['sender_name']);
    }
    function mysite_cancelled($order_id) {
        $order = wc_get_order( $order_id );
        $billing_email  = $order->get_billing_phone();
        $client = new Client();
        $response = $client->Messages->Send($order->get_billing_phone(),
'Dear '.$order->get_billing_first_name().' '.$order->get_billing_last_name().'

Thank you for your order.
Order '.$order->get_order_number().' of SAR '.$order->get_total(). ' has been '.$order->get_status().'

For More Information Contact Us: 920025833'
            ,get_option( 'unifonic_data' )['sender_name']);
        // arabic message
        $response = $client->Messages->Send($order->get_billing_phone(),
'عزيز '.$order->get_billing_first_name().' '.$order->get_billing_last_name().'

شكرا لتسوقك عبر موقع تمكين الإلكتروني..
رقم الطلب  '.$order->get_order_number().' اجمالي المبلغ  '.$order->get_total(). ' ريال و حالة الطلب   '.$order->get_status().'

لمزيد من المعلومات نرجو منك التواصل معنا عبر الرقم الموحد:: 920025833'
            ,get_option( 'unifonic_data' )['sender_name']);
    }

    public static function init() {
    	
    }
}
?>