<?php


    return array(
        'AppSid' => get_option( 'unifonic_data' )['api_key'],
        'ApiURL' => 'http://api.unifonic.com/rest/',
    );
